package com.likelion.demo.domain.bookmark.web.dto;

public record BookmarkToggleRes(
        String status // on / off
) {
}
