package com.likelion.demo.domain.programData.service;

import org.springframework.stereotype.Service;

import java.io.IOException;


public interface ProgramService {
    //비교과 프로그램 저장
    void importProgramsFromJson();


}
