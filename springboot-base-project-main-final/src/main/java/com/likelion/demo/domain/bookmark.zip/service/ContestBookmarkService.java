package com.likelion.demo.domain.bookmark.service;

public interface ContestBookmarkService {
    boolean toggle(Long memberId, Long contentId);
}
