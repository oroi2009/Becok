package com.likelion.demo.domain.bookmark.service;

public interface ProgramBookmarkService {
    boolean toggle(Long memberId, Long contentId);
}
